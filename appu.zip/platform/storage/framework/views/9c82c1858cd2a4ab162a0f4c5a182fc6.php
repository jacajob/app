


<?php $__env->startSection('hijos'); ?>
<h1>Editar cliente</h1>

<div class="row">
    <div class="col">
     <form action="/clientes/<?php echo e($datoCliente->id); ?>" class="form-control" method="POST">
     <?php echo csrf_field(); ?>
     <?php echo method_field('PUT'); ?>
     <div class="mb-3">
        <label for="" class="form-label">Nombre</label>
        <input type="text" class="form-control" id="nombre" value="<?php echo e($datoCliente->nombre); ?>" name="nombre">
     </div>
    
     <div class="mb-3">
        <label for="" class="form-label">Apellido</label>
        <input type="text" class="form-control" id="apellido" value="<?php echo e($datoCliente->apellido); ?>" name="apellido">
     </div>

     <div class="mb-3">
        <label for="" class="form-label">Telefono</label>
        <input type="text" class="form-control" id="telefono" value="<?php echo e($datoCliente->telefono); ?>" name="telefono">
     </div>
    
     <div class="mb-3">
        <button type="submit" class="btn btn-primary">Guardar</button>
        <a href="/clientes" class="btn btn-danger">Cancelar</a>
     </div>

     </form>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cuerpo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\appu\resources\views/cliente/edit.blade.php ENDPATH**/ ?>