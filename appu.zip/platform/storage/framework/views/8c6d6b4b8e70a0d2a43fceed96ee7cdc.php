


<?php $__env->startSection('hijos'); ?>
<h1>Eliminar cliente</h1>

<div class="row">
    <div class="col">
     <form action="/clientes/" class="form-control" method="POST">
     <?php echo csrf_field(); ?>
     <?php echo e($clienteEliminado->id); ?>

     <div class="mb-3">
        <label for="" class="form-label">Nombre</label>
        <input type="text" class="form-control" id="nombre" value="<?php echo e($clienteEliminado->nombre); ?>" name="nombre">
     </div>
    
     <div class="mb-3">
        <label for="" class="form-label">Apellido</label>
        <input type="text" class="form-control" id="apellido" value="<?php echo e($clienteEliminado->apellido); ?>" name="apellido">
     </div>

     <div class="mb-3">
        <label for="" class="form-label">Telefono</label>
        <input type="text" class="form-control" id="telefono" value="<?php echo e($clienteEliminado->telefono); ?>" name="telefono">
     </div>
    
     <div class="mb-3">
        <button type="submit" class="btn btn-danger">Eliminar</button>
        <a href="/clientes" class="btn btn-primary">Cancelar</a>
     </div>

     </form>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cuerpo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\appu\resources\views/cliente/delete.blade.php ENDPATH**/ ?>