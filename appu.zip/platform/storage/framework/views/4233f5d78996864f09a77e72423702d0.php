


<?php $__env->startSection('hijos'); ?>

<h1>Lista de Clientes</h1>
   <a href="clientes/create" class="btn btn-success">Crear</a>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Telefono</th>
                <th>Procesos</th>
            </tr>

        </thead>


        <tbody>
            
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo e($cliente->id); ?></th>
                <th><?php echo e($cliente->nombre); ?></th>
                <th><?php echo e($cliente->apellido); ?></th>
                <th><?php echo e($cliente->telefono); ?></th>
                <th>
                    
                    <form action="/clientes/<?php echo e($cliente->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('Delete'); ?>
                    <a href="/clientes/<?php echo e($cliente->id); ?>/edit" class="btn btn-primary">Editar</a>
                    <a href="/clientes/<?php echo e($cliente->id); ?>" class="btn btn-primary">Borrar 1</a>
                    <button type="submit" class="btn btn-primary">Borra 2</button>
                    </form>
                    
                </th>
            </tr>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>

    </table>




<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.cuerpo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\appu\resources\views/cliente/index.blade.php ENDPATH**/ ?>