<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista Personas</title>
</head>
<body>
    <h1>Lista Personas</h1>
</body>
</html><?php /**PATH C:\laragon\www\appu\resources\views/persona.blade.php ENDPATH**/ ?>